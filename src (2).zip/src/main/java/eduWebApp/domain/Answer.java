 package eduWebApp.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

//@Entity(name= "Answer")
public class Answer {
//	@Id
//	@GeneratedValue(strategy=GenerationType.TABLE)
//	@Column(name = "answer_id")
//	private int answer_id;
//	@Column(name = "question_id")
//	private int question;
//	@Column(name = "user_id")
//	private int user_id;
//	@Column(name = "answers")
//	private String answers;
//	public int getAnswer_id() {
//		return answer_id;
//	}
//	public void setAnswer_id(int answer_id) {
//		this.answer_id = answer_id;
//	}
//	public int getQuestion() {
//		return question;
//	}
//	public void setQuestion(int question) {
//		this.question = question;
//	}
//	public int getUser_id() {
//		return user_id;
//	}
//	public void setUser_id(int user_id) {
//		this.user_id = user_id;
//	}
//	public String getAnswers() {
//		return answers;
//	}
//	public void setAnswers(String answers) {
//		this.answers = answers;
//	}
//	
//	public Answer() {}
//	
//	public Answer(int answer_id, int question, int user_id, String answers) {
//		super();
//		this.answer_id = answer_id;
//		this.question = question;
//		this.user_id = user_id;
//		this.answers = answers;
	}

	
	
	
	


